# 部分国家名称及相关信息

附录2印刷页130—132，供教学参考。以下按原表次序记录。此表的国家、人称名词和相关形容词单独使用，主词表的阶段标记由主词条查询。

| 页 | 国家 | Country | Person | Related adjective |
|---:|---|---|---|---|
| 130 | 阿富汗 | Afghanistan | Afghan | Afghan |
| 130 | 阿尔及利亚 | Algeria | Algerian | Algerian |
| 130 | 阿根廷 | Argentina | Argentinian | Argentinian |
| 130 | 澳大利亚 | Australia | Australian | Australian |
| 130 | 奥地利 | Austria | Austrian | Austrian |
| 130 | 比利时 | Belgium | Belgian | Belgian |
| 130 | 巴西 | Brazil | Brazilian | Brazilian |
| 130 | 加拿大 | Canada | Canadian | Canadian |
| 130 | 中国 | China | Chinese | Chinese |
| 130 | 哥伦比亚 | Colombia | Colombian | Colombian |
| 130 | 古巴 | Cuba | Cuban | Cuban |
| 130 | 丹麦 | Denmark | Dane | Danish |
| 130 | 朝鲜 | Democratic People’s Republic of Korea—DPRK | Korean | Korean |
| 130 | 埃及 | Egypt | Egyptian | Egyptian |
| 130 | 芬兰 | Finland | Finn | Finnish |
| 130 | 法国 | France | Frenchman/Frenchwoman | French |
| 130 | 德国 | Germany | German | German |
| 130 | 希腊 | Greece | Greek | Greek |
| 130 | 匈牙利 | Hungary | Hungarian | Hungarian |
| 130 | 印度 | India | Indian | Indian |
| 130 | 印度尼西亚 | Indonesia | Indonesian | Indonesian |
| 131 | 伊朗 | Iran | Iranian | Iranian |
| 131 | 伊拉克 | Iraq | Iraqi | Iraqi |
| 131 | 爱尔兰 | Ireland | Irish | Irish |
| 131 | 以色列 | Israel | Israeli | Israeli |
| 131 | 意大利 | Italy | Italian | Italian |
| 131 | 日本 | Japan | Japanese | Japanese |
| 131 | 约旦 | Jordan | Jordanian | Jordanian |
| 131 | 肯尼亚 | Kenya | Kenyan | Kenyan |
| 131 | 科威特 | Kuwait | Kuwaiti | Kuwaiti |
| 131 | 黎巴嫩 | Lebanon | Lebanese | Lebanese |
| 131 | 卢森堡 | Luxembourg | Luxembourger | Luxembourg |
| 131 | 马来西亚 | Malaysia | Malaysian | Malaysian |
| 131 | 墨西哥 | Mexico | Mexican | Mexican |
| 131 | 缅甸 | Myanmar | Burmese | Burmese |
| 131 | 荷兰 | Netherlands | Dutch | Dutch |
| 131 | 新西兰 | New Zealand | New Zealander | New Zealand |
| 131 | 挪威 | Norway | Norwegian | Norwegian |
| 131 | 巴基斯坦 | Pakistan | Pakistani | Pakistani |
| 131 | 巴拿马 | Panama | Panamanian | Panamanian |
| 131 | 菲律宾 | Philippines | Filipino | Philippine |
| 131 | 波兰 | Poland | Polish | Polish |
| 131 | 葡萄牙 | Portugal | Portuguese | Portuguese |
| 131 | 韩国 | Republic of Korea—ROK | Korean | Korean |
| 132 | 俄罗斯 | Russia | Russian | Russian |
| 132 | 沙特阿拉伯 | Saudi Arabia | Saudi Arabian | Saudi Arabian |
| 132 | 新加坡 | Singapore | Singaporean | Singaporean |
| 132 | 南非 | South Africa | South African | South African |
| 132 | 西班牙 | Spain | Spaniard | Spanish |
| 132 | 瑞典 | Sweden | Swedish | Swedish |
| 132 | 瑞士 | Switzerland | Swiss | Swiss |
| 132 | 泰国 | Thailand | Thai | Thai |
| 132 | 土耳其 | Türkiye | Turk | Turkish |
| 132 | 英国 | the United Kingdom—UK | Briton | British |
| 132 | 美国 | the United States of America—USA | American | American |
| 132 | 越南 | Vietnam | Vietnamese | Vietnamese |
