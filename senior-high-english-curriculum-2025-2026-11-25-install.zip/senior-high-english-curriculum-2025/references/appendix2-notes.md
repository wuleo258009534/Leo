# 附录2词汇表的用法

主词表见[可检索数据](appendix2-vocabulary.json)，收录印刷页73—129所列条目。印刷页130—132是另列的[部分国家名称及相关信息](appendix2-country-reference.md)。条目原样字段保留空格、括注、斜线和拼写，星号单列，统一去掉星号前的排版空格。

| 统计依据 | 无星 | 一星 | 两星 | 合计 |
|---|---:|---:|---:|---:|
| 附录首页文字说明 | 1600 | 500 | 1000 | 3100 |
| 按指定PDF词条行逐页计数 | 1600 | 502 | 997 | 3099 |

两栏阅读顺序为先左栏、后右栏。每个印刷词条行算一条，斜线并列或括注仍随原条目保留。26个字母标题不计入，印刷页98的代词 **I** 单列入库。对主表57页，用 pypdf 和 PDFium 分别取字，并按页去除页眉和空白比较字母、符号及顺序。两份逐页序列一致。差异原因尚未确认，原星号按页保留。地方可依实际增加200个单词，提高类累计约4100为正文学习要求。见印刷页18—19、73。

## 查询

从技能目录运行 [lookup_vocabulary.py](../scripts/lookup_vocabulary.py)：

```powershell
python scripts/lookup_vocabulary.py --stats
python scripts/lookup_vocabulary.py analyse analyze 'ice cream' China china
python scripts/lookup_vocabulary.py --ignore-case Organize
python scripts/lookup_vocabulary.py --page 98
```

查询输出匹配类型、课程阶段、印刷页与PDF页。判断范围时保留原句，分别检查直接收录、括注变体、屈折形式、规则派生、专名和语境可推断性。引号内的多词表达按整个条目查询。默认区分大小写，弯引号与直引号等价。括注展开、等值表达和屈折形式关联原词条，独立收录状态需要看它是否还有自己的词条。例：`app (=application)` 列在无星级，`application*` 单独列在必修级。读出两条证据后报告具体查询结果。

原表个别写法与常见拼写有差异，例如印刷页98所写 `humourous*`。报告原表字段时照录。判断写作规范时应另查词典，并说明两种证据各自支持的结论。

批量查阅时直接读取JSON，勿将词表全量送入普通备课对话。查询脚本做字面检索，派生或词形归并由具体语境与证据决定。试题中未在词表找到的形式，仍需依据任务考查点、语境支持与学生负荷判断。
