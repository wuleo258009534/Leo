"""只读检索本地PDF逐页提取缓存；不下载、不修改来源，不代替原页查证。"""
import argparse
import json
import sys
from pathlib import Path


def page_set(value):
    result = set()
    for part in value.split(','):
        ends = part.strip().split('-')
        if len(ends) == 1:
            start = end = int(ends[0])
        elif len(ends) == 2:
            start, end = map(int, ends)
        else:
            raise ValueError('页码格式应为50或44-50,76')
        if start < 1 or end < start:
            raise ValueError('页码必须从1开始，范围结束不得小于起始')
        result.update(range(start, end + 1))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--corpus', type=Path, required=True, help='本地pages.json路径')
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--find', help='字面检索，输出命中页完整文字')
    mode.add_argument('--pages', help='PDF页序号，如50或44-50,76')
    parser.add_argument('--limit', type=int, default=5, help='检索结果最多页数，默认5；指定页不受此限')
    args = parser.parse_args()
    if args.limit < 1 or args.find == '':
        parser.error('limit必须为正数，find不能是空串')
    try:
        pages = json.loads(args.corpus.read_text(encoding='utf-8'))
        if not isinstance(pages, list) or not all(
            isinstance(p, dict) and isinstance(p.get('pdf_page'), int)
            and isinstance(p.get('text'), str) for p in pages
        ):
            raise ValueError('缓存应为含pdf_page和text字段的逐页列表')
        if args.pages:
            selected = page_set(args.pages)
            missing = selected - {p['pdf_page'] for p in pages}
            if missing:
                raise ValueError('缓存不存在这些页：' + ','.join(map(str, sorted(missing))))
            matches = [p for p in pages if p['pdf_page'] in selected]
        else:
            matches = [p for p in pages if args.find in p['text']]
            print(f'命中{len(matches)}页，最多显示{args.limit}页；未命中不证明原PDF不存在。')
            matches = matches[:args.limit]
        for p in matches:
            n = p['pdf_page']
            if n < 4:
                label = '封面或目录'
            elif n == 178 and not p['text'].strip():
                label = '末页空白'
            else:
                label = f'印刷页{n-3}'
            print(f'\n=== PDF第{n}页 / {label} ===\n{p["text"]}')
        return 0
    except (OSError, ValueError, TypeError) as error:
        print(f'无法读取：{error}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    raise SystemExit(main())
