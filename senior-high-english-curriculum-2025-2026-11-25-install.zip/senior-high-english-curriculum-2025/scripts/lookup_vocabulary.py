"""查附录2的原样词条、课程标记和印刷页码。"""
import argparse
import json
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

SOURCE = Path(__file__).resolve().parents[1] / 'references' / 'appendix2-vocabulary.json'
FIELDS = {
    'entry': '原样词条',
    'headword': '词条主词',
    'variants': '括注拼写变体',
    'grouped_forms': '斜线合列形式',
    'optional_form': '括注可选形式',
    'inflections': '括注屈折形式',
    'equivalents': '括注等值形式',
    'expanded_or_equivalent': '括注展开或等值形式',
}
NON_DIRECT = {'inflections', 'equivalents', 'expanded_or_equivalent'}
STAGES = ['义务教育基础', '高中必修新增', '选择性必修新增']


def key(text):
    # 保留大小写，避免 China 与 china、Miss 与 miss 合并。
    return ' '.join(unicodedata.normalize('NFC', text).replace('’', "'").split())


def index_rows(rows):
    index = defaultdict(list)
    for entry in rows:
        keys_for_entry = set()
        for field in FIELDS:
            values = entry.get(field, [])
            for value in [values] if isinstance(values, str) else values:
                term = key(value)
                if term not in keys_for_entry:
                    index[term].append((field, entry))
                    keys_for_entry.add(term)
    return index


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('words', nargs='*', help='查询项。多词表达请加引号。')
    parser.add_argument('--ignore-case', action='store_true', help='另查不同大小写，明示匹配方式')
    parser.add_argument('--stats', action='store_true', help='显示按印刷词条记录的统计')
    parser.add_argument('--page', type=int, help='列出指定印刷页（73–129）的词条')
    args = parser.parse_args()
    if not (args.words or args.page is not None or args.stats):
        parser.error('请给出词语、印刷页码或 --stats')
    if args.page is not None and not 73 <= args.page <= 129:
        parser.error('主词表印刷页范围为73–129')

    rows = json.loads(SOURCE.read_text(encoding='utf-8'))
    if args.stats:
        counts = Counter(row['stars'] for row in rows)
        print(f'印刷记录 {len(rows)} 条（无星 {counts[0]}、一星 {counts[1]}、两星 {counts[2]}）')
        print('附录说明列3100（1600／500／1000）。统计口径见附录2说明文件。')
    if args.page is not None:
        for entry in rows:
            if entry['page'] == args.page:
                print(f"{entry['entry']}{'*' * entry['stars']}")
    index = index_rows(rows)
    for word in args.words:
        term = key(word)
        found = [(field, entry, False) for field, entry in index.get(term, [])]
        if args.ignore_case:
            found.extend((field, entry, True) for k, values in index.items()
                         if k != term and k.casefold() == term.casefold()
                         for field, entry in values)
        if not found:
            print(f'{word} → 字面未匹配。可复查词形、构词和语境。')
        found.sort(key=lambda match: (match[2], match[0] in NON_DIRECT))
        for field, entry, case_changed in found:
            stars, page = entry['stars'], entry['page']
            details = FIELDS[field]
            if case_changed:
                details += '，大小写不同'
            if field in NON_DIRECT:
                details += '，阶段属于所示原词条'
            print(f"{word} → {entry['entry']}{'*' * stars}｜{STAGES[stars]}｜印刷页{page}（PDF第{page+3}页）｜{details}")


if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    main()
